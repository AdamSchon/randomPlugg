#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "list.h"

typedef struct list list_t;
typedef struct node node_t;

struct list
{
  node_t *first;
};

struct node
{
  /// TODO
  int element;
};

/// Skapar en ny node med ett givet element (du får ändra denna om du vill)
static node_t *node_create(int element)
{
  node_t *result = malloc(sizeof(node_t));
  *result = (node_t) {
    .element = element
  };
  return result;
}
  
list_t *ioopm_list_create()
{
  /// TODO
}

void ioopm_list_destroy(list_t *list)
{
  /// TODO
}

void ioopm_list_prepend(list_t *list, int element)
{
  /// TODO
}

void ioopm_list_append(list_t *list, int element)
{
  /// TODO
}

bool ioopm_list_remove(list_t *list, int index)
{
  /// TODO
}

int *ioopm_list_get(list_t *list, int index)
{
  /// TODO
}

/// Du får ändra på denna kod om du vill -- t.ex. för att
/// den inte funkar enligt din design, eller för att det
/// är enklare att skriva om den än att förstå den!
bool ioopm_list_contains(list_t *list, int element)
{
  node_t *stop = list->first;
  node_t *cursor = stop->next;

  while (cursor != stop)
    {
      if (cursor->element == element) return true;
      cursor = cursor->next;
    }

  return false;
}

int ioopm_list_size(list_t *list)
{
  /// TODO
}
